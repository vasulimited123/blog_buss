"""
Seed the database with realistic demo content for the wellness niche.

Idempotent: uses get_or_create keyed on slug/name, so running it repeatedly
won't create duplicates. Run with:

    python manage.py seed_demo

Pass --clear to remove the earlier throwaway "test-*" posts first.
"""

from django.core.management.base import BaseCommand
from django.utils import timezone

from blog.models import Author, Category, MedicalReviewer, Post, Tag


CATEGORIES = [
    ("Sexual Wellness", "Evidence-based education on sexual health, desire, and intimacy."),
    ("Marriage & Intimacy", "Physical and emotional intimacy in long-term relationships."),
    ("Relationship Psychology", "The psychology behind attraction, desire, and connection."),
    ("Men's Health", "Physical and mental wellbeing topics relevant to men."),
    ("Women's Health", "Physical and mental wellbeing topics relevant to women."),
]

AUTHORS = [
    ("Dr. Ananya Rao", "PhD, Clinical Psychologist",
     "Ananya writes about the psychology of relationships and desire, translating "
     "research into practical, judgment-free guidance."),
    ("Dr. Vikram Mehta", "MD, Family Medicine",
     "Vikram focuses on men's and women's health, with an emphasis on approachable, "
     "accurate medical education."),
]

REVIEWER = (
    "Dr. Sunita Kapoor",
    "MD, Psychiatrist & Certified Sex Therapist",
    "Dr. Kapoor reviews clinical claims for accuracy and tone.",
)

TAGS = [
    "communication", "desire", "couples", "intimacy", "anxiety",
    "hormones", "confidence", "aging", "stress", "attachment",
]

# (title, category_name, post_type, excerpt, focus_keyword, sensitivity)
POSTS = [
    ("Why Physical Intimacy Fades After 5 Years — and How Couples Rebuild It",
     "Marriage & Intimacy", "standard",
     "Desire naturally shifts in long relationships. Here's what the research says "
     "and a therapist-backed plan to reconnect.",
     "intimacy fades in marriage", "mature"),

    ("He Wants It Daily, She Wants It Weekly: Resolving Desire Mismatch",
     "Marriage & Intimacy", "standard",
     "Desire discrepancy is one of the most common issues couples face. A practical "
     "framework for meeting in the middle.",
     "desire mismatch couples", "mature"),

    ("12 Myths About Sexual Health, Debunked by Experts",
     "Sexual Wellness", "listicle",
     "From frequency 'norms' to performance worries, we separate fact from fiction "
     "with expert input.",
     "sexual health myths", "mature"),

    ("How We Rebuilt Intimacy After Two Years of Distance — A Couple's Story",
     "Marriage & Intimacy", "story",
     "One couple shares, anonymously, how they moved from roommates back to partners.",
     "rebuild intimacy after distance", "mature"),

    ("Couples Therapy vs Sex Therapy: Which Is Right for You?",
     "Relationship Psychology", "comparison",
     "They sound similar but solve different problems. A clear comparison to help "
     "you choose.",
     "couples therapy vs sex therapy", "general"),

    ("The Psychology of Losing Attraction — and How to Rebuild It",
     "Relationship Psychology", "standard",
     "Attraction changes over time for understandable reasons. Here's the psychology "
     "and what actually helps.",
     "losing attraction in relationship", "mature"),

    ("Performance Anxiety: A Cognitive-Behavioral Approach That Works",
     "Men's Health", "standard",
     "Performance worries are common and treatable. A step-by-step CBT-informed "
     "approach explained simply.",
     "performance anxiety", "mature"),

    ("Is Your Relationship Emotionally Healthy? Take This Quiz",
     "Relationship Psychology", "quiz",
     "A reflective self-check on communication, trust, and connection.",
     "healthy relationship quiz", "general"),
]


class Command(BaseCommand):
    help = "Seed the database with realistic demo content."

    def add_arguments(self, parser):
        parser.add_argument(
            "--clear",
            action="store_true",
            help="Delete earlier throwaway test-* posts before seeding.",
        )

    def handle(self, *args, **options):
        if options["clear"]:
            deleted, _ = Post.objects.filter(slug__startswith="test-").delete()
            self.stdout.write(self.style.WARNING(f"Removed {deleted} test-* object(s)."))

        # Categories
        categories = {}
        for name, desc in CATEGORIES:
            cat, _ = Category.objects.get_or_create(name=name, defaults={"description": desc})
            categories[name] = cat
        self.stdout.write(f"Categories: {len(categories)}")

        # Authors
        authors = []
        for name, creds, bio in AUTHORS:
            a, _ = Author.objects.get_or_create(
                name=name, defaults={"credentials": creds, "bio": bio}
            )
            authors.append(a)
        self.stdout.write(f"Authors: {len(authors)}")

        # Reviewer
        reviewer, _ = MedicalReviewer.objects.get_or_create(
            name=REVIEWER[0], defaults={"credentials": REVIEWER[1], "bio": REVIEWER[2]}
        )

        # Tags
        tags = []
        for t in TAGS:
            tag, _ = Tag.objects.get_or_create(name=t)
            tags.append(tag)
        self.stdout.write(f"Tags: {len(tags)}")

        # Posts
        created_count = 0
        for i, (title, cat_name, ptype, excerpt, keyword, sensitivity) in enumerate(POSTS):
            author = authors[i % len(authors)]
            body = (
                f"<p>{excerpt}</p>"
                "<h2>What the research says</h2>"
                "<p>This is placeholder body content for the demo. In production, "
                "each article would be a 1,500+ word, expert-written piece with "
                "citations and a warm, clinical tone.</p>"
                "<h2>What actually helps</h2>"
                "<p>Practical, step-by-step guidance goes here, framed for real "
                "couples and individuals.</p>"
                "<blockquote>You are not alone — these experiences are far more "
                "common than most people realize.</blockquote>"
            )
            post, created = Post.objects.get_or_create(
                title=title,
                defaults={
                    "excerpt": excerpt,
                    "body": body,
                    "author": author,
                    "category": categories[cat_name],
                    "post_type": ptype,
                    "status": Post.Status.PUBLISHED,
                    "published_at": timezone.now(),
                    "medical_reviewer": reviewer,
                    "reviewed_at": timezone.now().date(),
                    "sensitivity": sensitivity,
                    "focus_keyword": keyword,
                    "meta_description": excerpt[:160],
                    "sources": [
                        "https://www.ncbi.nlm.nih.gov/",
                        "https://www.who.int/health-topics/sexual-health",
                    ],
                    "content_warning": (
                        "This article discusses adult relationship topics."
                        if sensitivity != "general" else ""
                    ),
                },
            )
            if created:
                # Attach a few tags deterministically.
                post.tags.add(tags[i % len(tags)], tags[(i + 3) % len(tags)])
                created_count += 1

        self.stdout.write(self.style.SUCCESS(
            f"Seeding complete. Created {created_count} new post(s); "
            f"{Post.published.count()} published posts total."
        ))
